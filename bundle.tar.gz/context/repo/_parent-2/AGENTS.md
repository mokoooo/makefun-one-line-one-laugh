# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Conventions

- **実装前に先行研究・既存OSSを調査する（2026-11-25、ユーザー指示・Phase 3-R）**: 新規機能を実装する前に、必ず関連する先行研究・論文・既存OSSを調査し、再利用可能性（全面置換／部分再利用／方法論の適用／独自実装の維持）を確認してから着手する。READMEだけで判断せず、主要ソースコード・テスト・評価方法まで確認する。優れた既存実装がある場合は独自実装に固執しない。
